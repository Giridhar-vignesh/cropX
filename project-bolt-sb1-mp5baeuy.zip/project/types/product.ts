export interface Product {
  id: string;
  name: string;
  category: 'vegetables' | 'grains' | 'herbs';
  price: number;
  imageUrl: string;
  description: string;
  farmer_id: string;
  created_at: string;
}

export interface Order {
  id: string;
  user_id: string;
  total_price: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  created_at: string;
  items: OrderItem[];
}

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string;
  quantity: number;
  price: number;
  product?: Product;
}

export interface User {
  id: string;
  email: string;
  role: 'farmer' | 'consumer';
  name?: string;
  avatar_url?: string;
}