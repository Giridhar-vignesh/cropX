import { create } from 'zustand';
import { Product } from '../types/product';

interface CartItem {
  product: Product;
  quantity: number;
}

interface CartStore {
  items: CartItem[];
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  getTotalPrice: () => number;
  getTotalItems: () => number;
}

export const useCartStore = create<CartStore>((set, get) => ({
  items: [],
  
  addToCart: (product: Product) => {
    set((state) => {
      const existingItem = state.items.find(item => item.product.id === product.id);
      
      if (existingItem) {
        return {
          items: state.items.map(item => 
            item.product.id === product.id 
              ? { ...item, quantity: item.quantity + 1 } 
              : item
          )
        };
      } else {
        return {
          items: [...state.items, { product, quantity: 1 }]
        };
      }
    });
  },
  
  removeFromCart: (productId: string) => {
    set((state) => ({
      items: state.items.filter(item => item.product.id !== productId)
    }));
  },
  
  updateQuantity: (productId: string, quantity: number) => {
    set((state) => ({
      items: state.items.map(item => 
        item.product.id === productId 
          ? { ...item, quantity: Math.max(1, quantity) } 
          : item
      )
    }));
  },
  
  clearCart: () => {
    set({ items: [] });
  },
  
  getTotalPrice: () => {
    return get().items.reduce(
      (total, item) => total + (item.product.price * item.quantity), 
      0
    );
  },
  
  getTotalItems: () => {
    return get().items.reduce(
      (total, item) => total + item.quantity, 
      0
    );
  }
}));

interface AuthStore {
  user: any | null;
  userRole: 'farmer' | 'consumer' | null;
  isLoading: boolean;
  setUser: (user: any | null) => void;
  setUserRole: (role: 'farmer' | 'consumer' | null) => void;
  setLoading: (isLoading: boolean) => void;
  clearAuth: () => void;
}

export const useAuthStore = create<AuthStore>((set) => ({
  user: null,
  userRole: null,
  isLoading: true,
  setUser: (user) => set({ user }),
  setUserRole: (role) => set({ userRole: role }),
  setLoading: (isLoading) => set({ isLoading }),
  clearAuth: () => set({ user: null, userRole: null }),
}));