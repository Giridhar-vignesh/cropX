import React from 'react';
import { Tabs } from 'expo-router';
import { Chrome as Home, ShoppingCart, User, Plus, Package } from 'lucide-react-native';
import { useAuthStore, useCartStore } from '../../lib/store';
import { View, Text, StyleSheet } from 'react-native';

export default function TabLayout() {
  const { userRole } = useAuthStore();
  const cartItemCount = useCartStore(state => state.getTotalItems());
  
  const isFarmer = userRole === 'farmer';

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: '#2E7D32',
        tabBarInactiveTintColor: '#666',
        tabBarStyle: {
          borderTopWidth: 1,
          borderTopColor: '#eee',
        },
        headerShown: true,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Home',
          tabBarIcon: ({ color, size }) => <Home size={size} color={color} />,
          headerTitle: 'AgriMarket',
        }}
      />
      
      {isFarmer ? (
        <>
          <Tabs.Screen
            name="farmer/add-product"
            options={{
              title: 'Add Product',
              tabBarIcon: ({ color, size }) => <Plus size={size} color={color} />,
              headerTitle: 'Add New Product',
            }}
          />
          <Tabs.Screen
            name="farmer/my-products"
            options={{
              title: 'My Products',
              tabBarIcon: ({ color, size }) => <Package size={size} color={color} />,
              headerTitle: 'My Products',
            }}
          />
        </>
      ) : (
        <Tabs.Screen
          name="consumer/cart"
          options={{
            title: 'Cart',
            tabBarIcon: ({ color, size }) => (
              <View>
                <ShoppingCart size={size} color={color} />
                {cartItemCount > 0 && (
                  <View style={styles.badge}>
                    <Text style={styles.badgeText}>
                      {cartItemCount > 99 ? '99+' : cartItemCount}
                    </Text>
                  </View>
                )}
              </View>
            ),
            headerTitle: 'Shopping Cart',
          }}
        />
      )}
      
      <Tabs.Screen
        name="profile"
        options={{
          title: 'Profile',
          tabBarIcon: ({ color, size }) => <User size={size} color={color} />,
          headerTitle: 'My Profile',
        }}
      />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  badge: {
    position: 'absolute',
    right: -6,
    top: -4,
    backgroundColor: '#D32F2F',
    borderRadius: 10,
    minWidth: 18,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  badgeText: {
    color: 'white',
    fontSize: 10,
    fontWeight: 'bold',
    paddingHorizontal: 4,
  },
});